/*
 * blue.h
 *
 *  Created on: Apr 17, 2021
 *      Author: jasoni111
 */

#ifndef INC_BLUE_H_
#define INC_BLUE_H_

void sendfloat(char idx, float data);



#endif /* INC_BLUE_H_ */
