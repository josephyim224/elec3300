                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (Mac OS X x86_64)
                                      4 ;--------------------------------------------------------
                                      5 	.module main
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _main
                                     12 	.globl _drawPixel
                                     13 	.globl _display
                                     14 	.globl _ssd1306_begin
                                     15 	.globl _UART1_Cmd
                                     16 	.globl _UART1_Init
                                     17 	.globl _UART1_DeInit
                                     18 	.globl _I2C_Cmd
                                     19 	.globl _I2C_Init
                                     20 	.globl _GPIO_WriteReverse
                                     21 	.globl _GPIO_Init
                                     22 	.globl _initPeripherals
                                     23 	.globl _Delay
                                     24 ;--------------------------------------------------------
                                     25 ; ram data
                                     26 ;--------------------------------------------------------
                                     27 	.area DATA
                                     28 ;--------------------------------------------------------
                                     29 ; ram data
                                     30 ;--------------------------------------------------------
                                     31 	.area INITIALIZED
                                     32 ;--------------------------------------------------------
                                     33 ; Stack segment in internal ram 
                                     34 ;--------------------------------------------------------
                                     35 	.area	SSEG
      000001                         36 __start__stack:
      000001                         37 	.ds	1
                                     38 
                                     39 ;--------------------------------------------------------
                                     40 ; absolute external ram data
                                     41 ;--------------------------------------------------------
                                     42 	.area DABS (ABS)
                                     43 
                                     44 ; default segment ordering for linker
                                     45 	.area HOME
                                     46 	.area GSINIT
                                     47 	.area GSFINAL
                                     48 	.area CONST
                                     49 	.area INITIALIZER
                                     50 	.area CODE
                                     51 
                                     52 ;--------------------------------------------------------
                                     53 ; interrupt vector 
                                     54 ;--------------------------------------------------------
                                     55 	.area HOME
      008000                         56 __interrupt_vect:
      008000 82 00 80 07             57 	int s_GSINIT ; reset
                                     58 ;--------------------------------------------------------
                                     59 ; global & static initialisations
                                     60 ;--------------------------------------------------------
                                     61 	.area HOME
                                     62 	.area GSINIT
                                     63 	.area GSFINAL
                                     64 	.area GSINIT
      008007                         65 __sdcc_init_data:
                                     66 ; stm8_genXINIT() start
      008007 AE 00 00         [ 2]   67 	ldw x, #l_DATA
      00800A 27 07            [ 1]   68 	jreq	00002$
      00800C                         69 00001$:
      00800C 72 4F 00 00      [ 1]   70 	clr (s_DATA - 1, x)
      008010 5A               [ 2]   71 	decw x
      008011 26 F9            [ 1]   72 	jrne	00001$
      008013                         73 00002$:
      008013 AE 00 00         [ 2]   74 	ldw	x, #l_INITIALIZER
      008016 27 09            [ 1]   75 	jreq	00004$
      008018                         76 00003$:
      008018 D6 80 23         [ 1]   77 	ld	a, (s_INITIALIZER - 1, x)
      00801B D7 00 00         [ 1]   78 	ld	(s_INITIALIZED - 1, x), a
      00801E 5A               [ 2]   79 	decw	x
      00801F 26 F7            [ 1]   80 	jrne	00003$
      008021                         81 00004$:
                                     82 ; stm8_genXINIT() end
                                     83 	.area GSFINAL
      008021 CC 80 04         [ 2]   84 	jp	__sdcc_program_startup
                                     85 ;--------------------------------------------------------
                                     86 ; Home
                                     87 ;--------------------------------------------------------
                                     88 	.area HOME
                                     89 	.area HOME
      008004                         90 __sdcc_program_startup:
      008004 CC 80 24         [ 2]   91 	jp	_main
                                     92 ;	return from main will return to caller
                                     93 ;--------------------------------------------------------
                                     94 ; code
                                     95 ;--------------------------------------------------------
                                     96 	.area CODE
                           000000    97 	G$main$0$0 ==.
                           000000    98 	C$main.c$56$0_0$313 ==.
                                     99 ;	./main.c: 56: void main(void)
                                    100 ; genLabel
                                    101 ;	-----------------------------------------
                                    102 ;	 function main
                                    103 ;	-----------------------------------------
                                    104 ;	Register assignment is optimal.
                                    105 ;	Stack space usage: 0 bytes.
      008024                        106 _main:
                           000000   107 	C$main.c$58$1_0$313 ==.
                                    108 ;	./main.c: 58: initPeripherals();
                                    109 ; genCall
      008024 CD 80 6C         [ 4]  110 	call	_initPeripherals
                           000003   111 	C$main.c$60$1_0$313 ==.
                                    112 ;	./main.c: 60: ssd1306_begin();
                                    113 ; genCall
      008027 CD 00 00         [ 4]  114 	call	_ssd1306_begin
                           000006   115 	C$main.c$61$1_0$313 ==.
                                    116 ;	./main.c: 61: drawPixel(10, 10, SSD1306_WHITE);
                                    117 ; genIPush
      00802A 4B 01            [ 1]  118 	push	#0x01
      00802C 4B 00            [ 1]  119 	push	#0x00
                                    120 ; genIPush
      00802E 4B 0A            [ 1]  121 	push	#0x0a
      008030 4B 00            [ 1]  122 	push	#0x00
                                    123 ; genIPush
      008032 4B 0A            [ 1]  124 	push	#0x0a
      008034 4B 00            [ 1]  125 	push	#0x00
                                    126 ; genCall
      008036 CD 00 00         [ 4]  127 	call	_drawPixel
      008039 5B 06            [ 2]  128 	addw	sp, #6
                           000017   129 	C$main.c$62$1_0$313 ==.
                                    130 ;	./main.c: 62: drawPixel(10, 11, SSD1306_BLACK);
                                    131 ; genIPush
      00803B 5F               [ 1]  132 	clrw	x
      00803C 89               [ 2]  133 	pushw	x
                                    134 ; genIPush
      00803D 4B 0B            [ 1]  135 	push	#0x0b
      00803F 4B 00            [ 1]  136 	push	#0x00
                                    137 ; genIPush
      008041 4B 0A            [ 1]  138 	push	#0x0a
      008043 4B 00            [ 1]  139 	push	#0x00
                                    140 ; genCall
      008045 CD 00 00         [ 4]  141 	call	_drawPixel
      008048 5B 06            [ 2]  142 	addw	sp, #6
                           000026   143 	C$main.c$63$1_0$313 ==.
                                    144 ;	./main.c: 63: display();
                                    145 ; genCall
      00804A CD 00 00         [ 4]  146 	call	_display
                           000029   147 	C$main.c$65$1_0$313 ==.
                                    148 ;	./main.c: 65: while (1)
                                    149 ; genLabel
      00804D                        150 00102$:
                           000029   151 	C$main.c$67$2_0$314 ==.
                                    152 ;	./main.c: 67: GPIO_WriteReverse(LED0_GPIO_PORT, LED0_GPIO_PIN);
                                    153 ; genIPush
      00804D 4B 80            [ 1]  154 	push	#0x80
                                    155 ; genIPush
      00804F 4B 0A            [ 1]  156 	push	#0x0a
      008051 4B 50            [ 1]  157 	push	#0x50
                                    158 ; genCall
      008053 CD 00 00         [ 4]  159 	call	_GPIO_WriteReverse
      008056 5B 03            [ 2]  160 	addw	sp, #3
                           000034   161 	C$main.c$68$2_0$314 ==.
                                    162 ;	./main.c: 68: Delay(500000);
                                    163 ; genIPush
      008058 4B 20            [ 1]  164 	push	#0x20
      00805A 4B A1            [ 1]  165 	push	#0xa1
                                    166 ; genCall
      00805C CD 81 2A         [ 4]  167 	call	_Delay
      00805F 85               [ 2]  168 	popw	x
                           00003C   169 	C$main.c$69$2_0$314 ==.
                                    170 ;	./main.c: 69: Delay(500000);
                                    171 ; genIPush
      008060 4B 20            [ 1]  172 	push	#0x20
      008062 4B A1            [ 1]  173 	push	#0xa1
                                    174 ; genCall
      008064 CD 81 2A         [ 4]  175 	call	_Delay
      008067 85               [ 2]  176 	popw	x
                                    177 ; genGoto
      008068 CC 80 4D         [ 2]  178 	jp	00102$
                                    179 ; genLabel
      00806B                        180 00104$:
                           000047   181 	C$main.c$71$1_0$313 ==.
                                    182 ;	./main.c: 71: }
                                    183 ; genEndFunction
                           000047   184 	C$main.c$71$1_0$313 ==.
                           000047   185 	XG$main$0$0 ==.
      00806B 81               [ 4]  186 	ret
                           000048   187 	G$initPeripherals$0$0 ==.
                           000048   188 	C$main.c$73$1_0$315 ==.
                                    189 ;	./main.c: 73: void initPeripherals()
                                    190 ; genLabel
                                    191 ;	-----------------------------------------
                                    192 ;	 function initPeripherals
                                    193 ;	-----------------------------------------
                                    194 ;	Register assignment is optimal.
                                    195 ;	Stack space usage: 0 bytes.
      00806C                        196 _initPeripherals:
                           000048   197 	C$main.c$76$3_0$316 ==.
                                    198 ;	./main.c: 76: for (uint16_t i = 0; i < 0xffff; ++i)
                                    199 ; genAssign
      00806C 5F               [ 1]  200 	clrw	x
                                    201 ; genAssign
                                    202 ; genLabel
      00806D                        203 00106$:
                                    204 ; genCast
                                    205 ; genAssign
      00806D 90 93            [ 1]  206 	ldw	y, x
                                    207 ; genCmp
                                    208 ; genCmpTop
      00806F 90 A3 FF FF      [ 2]  209 	cpw	y, #0xffff
      008073 25 03            [ 1]  210 	jrc	00131$
      008075 CC 80 7C         [ 2]  211 	jp	00101$
      008078                        212 00131$:
                                    213 ; skipping generated iCode
                                    214 ; genPlus
      008078 5C               [ 1]  215 	incw	x
                                    216 ; genGoto
      008079 CC 80 6D         [ 2]  217 	jp	00106$
                                    218 ; genLabel
      00807C                        219 00101$:
                           000058   220 	C$main.c$79$2_0$317 ==.
                                    221 ;	./main.c: 79: disableInterrupts();
                                    222 ;	genInline
      00807C 9B               [ 1]  223 	sim
                           000059   224 	C$main.c$82$1_0$315 ==.
                                    225 ;	./main.c: 82: CLK->ICKR = CLK_ICKR_RESET_VALUE;
                                    226 ; genPointerSet
      00807D 35 01 50 C0      [ 1]  227 	mov	0x50c0+0, #0x01
                           00005D   228 	C$main.c$83$1_0$315 ==.
                                    229 ;	./main.c: 83: CLK->ECKR = CLK_ECKR_RESET_VALUE;
                                    230 ; genPointerSet
      008081 35 00 50 C1      [ 1]  231 	mov	0x50c1+0, #0x00
                           000061   232 	C$main.c$84$1_0$315 ==.
                                    233 ;	./main.c: 84: CLK->SWR = CLK_SWR_RESET_VALUE;
                                    234 ; genPointerSet
      008085 35 E1 50 C4      [ 1]  235 	mov	0x50c4+0, #0xe1
                           000065   236 	C$main.c$85$1_0$315 ==.
                                    237 ;	./main.c: 85: CLK->SWCR = CLK_SWCR_RESET_VALUE;
                                    238 ; genPointerSet
      008089 35 00 50 C5      [ 1]  239 	mov	0x50c5+0, #0x00
                           000069   240 	C$main.c$86$1_0$315 ==.
                                    241 ;	./main.c: 86: CLK->CKDIVR = CLK_CKDIVR_RESET_VALUE;
                                    242 ; genPointerSet
      00808D 35 18 50 C6      [ 1]  243 	mov	0x50c6+0, #0x18
                           00006D   244 	C$main.c$87$1_0$315 ==.
                                    245 ;	./main.c: 87: CLK->PCKENR1 = CLK_PCKENR1_RESET_VALUE;
                                    246 ; genPointerSet
      008091 35 FF 50 C7      [ 1]  247 	mov	0x50c7+0, #0xff
                           000071   248 	C$main.c$88$1_0$315 ==.
                                    249 ;	./main.c: 88: CLK->PCKENR2 = CLK_PCKENR2_RESET_VALUE;
                                    250 ; genPointerSet
      008095 35 FF 50 CA      [ 1]  251 	mov	0x50ca+0, #0xff
                           000075   252 	C$main.c$89$1_0$315 ==.
                                    253 ;	./main.c: 89: CLK->CSSR = CLK_CSSR_RESET_VALUE;
                                    254 ; genPointerSet
      008099 35 00 50 C8      [ 1]  255 	mov	0x50c8+0, #0x00
                           000079   256 	C$main.c$90$1_0$315 ==.
                                    257 ;	./main.c: 90: CLK->CCOR = CLK_CCOR_RESET_VALUE;
                                    258 ; genPointerSet
      00809D 35 00 50 C9      [ 1]  259 	mov	0x50c9+0, #0x00
                           00007D   260 	C$main.c$91$1_0$315 ==.
                                    261 ;	./main.c: 91: while ((CLK->CCOR & CLK_CCOR_CCOEN) != 0)
                                    262 ; genLabel
      0080A1                        263 00102$:
                                    264 ; genPointerGet
      0080A1 C6 50 C9         [ 1]  265 	ld	a, 0x50c9
                                    266 ; genAnd
      0080A4 44               [ 1]  267 	srl	a
      0080A5 24 03            [ 1]  268 	jrnc	00132$
      0080A7 CC 80 A1         [ 2]  269 	jp	00102$
      0080AA                        270 00132$:
                                    271 ; skipping generated iCode
                           000086   272 	C$main.c$93$1_0$315 ==.
                                    273 ;	./main.c: 93: CLK->CCOR = CLK_CCOR_RESET_VALUE;
                                    274 ; genPointerSet
      0080AA 35 00 50 C9      [ 1]  275 	mov	0x50c9+0, #0x00
                           00008A   276 	C$main.c$94$1_0$315 ==.
                                    277 ;	./main.c: 94: CLK->HSITRIMR = CLK_HSITRIMR_RESET_VALUE;
                                    278 ; genPointerSet
      0080AE 35 00 50 CC      [ 1]  279 	mov	0x50cc+0, #0x00
                           00008E   280 	C$main.c$95$1_0$315 ==.
                                    281 ;	./main.c: 95: CLK->SWIMCCR = CLK_SWIMCCR_RESET_VALUE;
                                    282 ; genPointerSet
      0080B2 35 00 50 CD      [ 1]  283 	mov	0x50cd+0, #0x00
                           000092   284 	C$main.c$96$1_0$315 ==.
                                    285 ;	./main.c: 96: CLK->CKDIVR &= (uint8_t)(~CLK_CKDIVR_HSIDIV);
                                    286 ; genPointerGet
      0080B6 C6 50 C6         [ 1]  287 	ld	a, 0x50c6
                                    288 ; genAnd
      0080B9 A4 E7            [ 1]  289 	and	a, #0xe7
                                    290 ; genPointerSet
      0080BB C7 50 C6         [ 1]  291 	ld	0x50c6, a
                           00009A   292 	C$main.c$97$1_0$315 ==.
                                    293 ;	./main.c: 97: CLK->CKDIVR |= (uint8_t)0;
                                    294 ; genPointerGet
      0080BE C6 50 C6         [ 1]  295 	ld	a, 0x50c6
                                    296 ; genPointerSet
      0080C1 C7 50 C6         [ 1]  297 	ld	0x50c6, a
                           0000A0   298 	C$main.c$100$1_0$315 ==.
                                    299 ;	./main.c: 100: GPIO_Init(TOP_BUTTON_GPIO_PORT, TOP_BUTTON_GPIO_PIN, GPIO_MODE_IN_FL_IT);
                                    300 ; genIPush
      0080C4 4B 20            [ 1]  301 	push	#0x20
                                    302 ; genIPush
      0080C6 4B 02            [ 1]  303 	push	#0x02
                                    304 ; genIPush
      0080C8 4B 00            [ 1]  305 	push	#0x00
      0080CA 4B 50            [ 1]  306 	push	#0x50
                                    307 ; genCall
      0080CC CD 00 00         [ 4]  308 	call	_GPIO_Init
      0080CF 5B 04            [ 2]  309 	addw	sp, #4
                           0000AD   310 	C$main.c$101$1_0$315 ==.
                                    311 ;	./main.c: 101: GPIO_Init(SIDE_BUTTON_GPIO_PORT, SIDE_BUTTON_GPIO_PIN, GPIO_MODE_IN_FL_IT);
                                    312 ; genIPush
      0080D1 4B 20            [ 1]  313 	push	#0x20
                                    314 ; genIPush
      0080D3 4B 08            [ 1]  315 	push	#0x08
                                    316 ; genIPush
      0080D5 4B 00            [ 1]  317 	push	#0x00
      0080D7 4B 50            [ 1]  318 	push	#0x50
                                    319 ; genCall
      0080D9 CD 00 00         [ 4]  320 	call	_GPIO_Init
      0080DC 5B 04            [ 2]  321 	addw	sp, #4
                           0000BA   322 	C$main.c$102$1_0$315 ==.
                                    323 ;	./main.c: 102: GPIO_Init(LED0_GPIO_PORT, LED0_GPIO_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
                                    324 ; genIPush
      0080DE 4B E0            [ 1]  325 	push	#0xe0
                                    326 ; genIPush
      0080E0 4B 80            [ 1]  327 	push	#0x80
                                    328 ; genIPush
      0080E2 4B 0A            [ 1]  329 	push	#0x0a
      0080E4 4B 50            [ 1]  330 	push	#0x50
                                    331 ; genCall
      0080E6 CD 00 00         [ 4]  332 	call	_GPIO_Init
      0080E9 5B 04            [ 2]  333 	addw	sp, #4
                           0000C7   334 	C$main.c$105$1_0$315 ==.
                                    335 ;	./main.c: 105: I2C_Init(100000, 0xA0, I2C_DUTYCYCLE_2, I2C_ACK_CURR, I2C_ADDMODE_7BIT, 16);
                                    336 ; genIPush
      0080EB 4B 10            [ 1]  337 	push	#0x10
                                    338 ; genIPush
      0080ED 4B 00            [ 1]  339 	push	#0x00
                                    340 ; genIPush
      0080EF 4B 01            [ 1]  341 	push	#0x01
                                    342 ; genIPush
      0080F1 4B 00            [ 1]  343 	push	#0x00
                                    344 ; genIPush
      0080F3 4B A0            [ 1]  345 	push	#0xa0
      0080F5 4B 00            [ 1]  346 	push	#0x00
                                    347 ; genIPush
      0080F7 4B A0            [ 1]  348 	push	#0xa0
      0080F9 4B 86            [ 1]  349 	push	#0x86
      0080FB 4B 01            [ 1]  350 	push	#0x01
      0080FD 4B 00            [ 1]  351 	push	#0x00
                                    352 ; genCall
      0080FF CD 00 00         [ 4]  353 	call	_I2C_Init
      008102 5B 0A            [ 2]  354 	addw	sp, #10
                           0000E0   355 	C$main.c$106$1_0$315 ==.
                                    356 ;	./main.c: 106: I2C_Cmd(ENABLE);
                                    357 ; genIPush
      008104 4B 01            [ 1]  358 	push	#0x01
                                    359 ; genCall
      008106 CD 00 00         [ 4]  360 	call	_I2C_Cmd
      008109 84               [ 1]  361 	pop	a
                           0000E6   362 	C$main.c$109$1_0$315 ==.
                                    363 ;	./main.c: 109: UART1_DeInit();
                                    364 ; genCall
      00810A CD 00 00         [ 4]  365 	call	_UART1_DeInit
                           0000E9   366 	C$main.c$110$1_0$315 ==.
                                    367 ;	./main.c: 110: UART1_Init((uint32_t)9600, UART1_WORDLENGTH_8D, UART1_STOPBITS_1, UART1_PARITY_NO,
                                    368 ; genIPush
      00810D 4B 0C            [ 1]  369 	push	#0x0c
                                    370 ; genIPush
      00810F 4B 69            [ 1]  371 	push	#0x69
                                    372 ; genIPush
      008111 4B 00            [ 1]  373 	push	#0x00
                                    374 ; genIPush
      008113 4B 00            [ 1]  375 	push	#0x00
                                    376 ; genIPush
      008115 4B 00            [ 1]  377 	push	#0x00
                                    378 ; genIPush
      008117 4B 80            [ 1]  379 	push	#0x80
      008119 4B 25            [ 1]  380 	push	#0x25
      00811B 5F               [ 1]  381 	clrw	x
      00811C 89               [ 2]  382 	pushw	x
                                    383 ; genCall
      00811D CD 00 00         [ 4]  384 	call	_UART1_Init
      008120 5B 09            [ 2]  385 	addw	sp, #9
                           0000FE   386 	C$main.c$113$1_0$315 ==.
                                    387 ;	./main.c: 113: UART1_Cmd(DISABLE);
                                    388 ; genIPush
      008122 4B 00            [ 1]  389 	push	#0x00
                                    390 ; genCall
      008124 CD 00 00         [ 4]  391 	call	_UART1_Cmd
      008127 84               [ 1]  392 	pop	a
                           000104   393 	C$main.c$115$2_0$318 ==.
                                    394 ;	./main.c: 115: enableInterrupts();
                                    395 ;	genInline
      008128 9A               [ 1]  396 	rim
                                    397 ; genLabel
      008129                        398 00108$:
                           000105   399 	C$main.c$116$2_0$315 ==.
                                    400 ;	./main.c: 116: }
                                    401 ; genEndFunction
                           000105   402 	C$main.c$116$2_0$315 ==.
                           000105   403 	XG$initPeripherals$0$0 ==.
      008129 81               [ 4]  404 	ret
                           000106   405 	G$Delay$0$0 ==.
                           000106   406 	C$main.c$123$2_0$320 ==.
                                    407 ;	./main.c: 123: void Delay(uint16_t nCount)
                                    408 ; genLabel
                                    409 ;	-----------------------------------------
                                    410 ;	 function Delay
                                    411 ;	-----------------------------------------
                                    412 ;	Register assignment is optimal.
                                    413 ;	Stack space usage: 0 bytes.
      00812A                        414 _Delay:
                           000106   415 	C$main.c$126$1_0$320 ==.
                                    416 ;	./main.c: 126: while (nCount != 0)
                                    417 ; genAssign
      00812A 1E 03            [ 2]  418 	ldw	x, (0x03, sp)
                                    419 ; genLabel
      00812C                        420 00101$:
                                    421 ; genIfx
      00812C 5D               [ 2]  422 	tnzw	x
      00812D 26 03            [ 1]  423 	jrne	00117$
      00812F CC 81 36         [ 2]  424 	jp	00104$
      008132                        425 00117$:
                           00010E   426 	C$main.c$128$2_0$321 ==.
                                    427 ;	./main.c: 128: nCount--;
                                    428 ; genMinus
      008132 5A               [ 2]  429 	decw	x
                                    430 ; genGoto
      008133 CC 81 2C         [ 2]  431 	jp	00101$
                                    432 ; genLabel
      008136                        433 00104$:
                           000112   434 	C$main.c$130$1_0$320 ==.
                                    435 ;	./main.c: 130: }
                                    436 ; genEndFunction
                           000112   437 	C$main.c$130$1_0$320 ==.
                           000112   438 	XG$Delay$0$0 ==.
      008136 81               [ 4]  439 	ret
                                    440 	.area CODE
                                    441 	.area CONST
                                    442 	.area INITIALIZER
                                    443 	.area CABS (ABS)
